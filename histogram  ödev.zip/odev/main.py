import cv2
import matplotlib.pyplot as plt
import numpy as np

img=cv2.imread("road.jpg")
b,g,r = cv2.split(img)
cv2.imshow("road",img)

plt.hist(b.ravel(), 256, [0,256])
plt.hist(g.ravel(), 256, [0,256])
plt.hist(r.ravel(), 256, [0,256])
plt.show()
cv2.waitKey()
